# Hive-Chataigne-Module

This is a simple Chataigne module for controling Hive Beeblade, Beebox and Nexus media engines with Chataigne.

Installation:

Copy all the files into a folder named Hive and then copy that folder into <Documents>/Chataigne/modules

Usage:
